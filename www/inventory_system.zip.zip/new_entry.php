<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit;
}
include 'config.php';

$success = $error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $stmt = $conn->prepare("INSERT INTO assets (
    asset_tag, tag_number, brand_model, serial_number,
    processor, hdd_ssd_size, recovery_tape, office_version,
    memory, ip_address, user, email_address
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
  
  $stmt->bind_param("ssssssssssss",
    $_POST['asset_tag'], $_POST['tag_number'], $_POST['brand_model'], $_POST['serial_number'],
    $_POST['processor'], $_POST['hdd_ssd_size'], $_POST['recovery_tape'], $_POST['office_version'],
    $_POST['memory'], $_POST['ip_address'], $_POST['user'], $_POST['email_address']
  );

  if ($stmt->execute()) {
    $success = "✅ Asset added successfully.";
  } else {
    $error = "❌ Failed to add asset: " . $stmt->error;
  }

  $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>New Entry</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: rgb(196, 196, 196); /* ash gray */
    }
    .container {
      background-color: white;
      border-radius: 10px;
      padding: 30px;
      margin-top: 30px;
      box-shadow: 0 0 10px rgba(0,0,0,0.3);
    }
    label {
      font-weight: 500;
    }
    .btn-primary {
      width: 100%;
    }
  </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="container">
  <h2 class="mb-4">➕ New Asset Entry</h2>

  <?php if ($success): ?>
    <div class="alert alert-success"><?= $success ?></div>
  <?php elseif ($error): ?>
    <div class="alert alert-danger"><?= $error ?></div>
  <?php endif; ?>

  <form method="POST">
    <?php
    $fields = [
      'asset_tag', 'tag_number', 'brand_model', 'serial_number', 'processor',
      'hdd_ssd_size', 'recovery_tape', 'office_version', 'memory',
      'ip_address', 'user', 'email_address'
    ];
    foreach ($fields as $field) {
      $type = $field === 'email_address' ? 'email' : 'text';
      $pattern = $field === 'email_address' ? "pattern='.*@gmail\.com'" : "";
      echo "
        <div class='mb-3'>
          <label class='form-label'>" . ucwords(str_replace("_", " ", $field)) . "</label>
          <input type='$type' name='$field' class='form-control' required $pattern>
        </div>";
    }
    ?>
    <button type="submit" class="btn btn-primary">Save Asset</button>
  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
