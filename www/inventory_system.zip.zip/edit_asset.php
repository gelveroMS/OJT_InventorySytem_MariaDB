<?php
include 'config.php';
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit;
}

$error = "";
$asset = null;

if (isset($_POST['id']) && !isset($_POST['update'])) {
  $stmt = $conn->prepare("SELECT * FROM assets WHERE id = ?");
  $stmt->bind_param("i", $_POST['id']);
  $stmt->execute();
  $result = $stmt->get_result();
  if ($result->num_rows > 0) {
    $asset = $result->fetch_assoc();
  } else {
    $error = "❌ No asset found with ID: " . htmlspecialchars($_POST['id']);
  }
}

if (isset($_POST['update'])) {
  $stmt = $conn->prepare("UPDATE assets SET asset_tag=?, tag_number=?, brand_model=?, serial_number=?, processor=?, hdd_ssd_size=?, recovery_tape=?, office_version=?, memory=?, ip_address=?, user=?, email_address=? WHERE id=?");
  $stmt->bind_param("ssssssssssssi", $_POST['asset_tag'], $_POST['tag_number'], $_POST['brand_model'], $_POST['serial_number'], $_POST['processor'], $_POST['hdd_ssd_size'], $_POST['recovery_tape'], $_POST['office_version'], $_POST['memory'], $_POST['ip_address'], $_POST['user'], $_POST['email_address'], $_POST['id']);
  $stmt->execute();
  echo "<div class='alert alert-success text-center mt-3'>✅ Asset updated successfully.</div>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Asset</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: rgb(196, 196, 196); /* ash gray */
    }
    .container {
      background-color: white;
      border-radius: 10px;
      padding: 30px;
      margin-top: 30px;
      box-shadow: 0 0 10px rgba(0,0,0,0.3);
    }
  </style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container">
  <h2 class="mb-4">✏️ Edit Asset</h2>

  <?php if ($error): ?>
    <div class="alert alert-danger"><?= $error ?></div>
  <?php endif; ?>

  <!-- Load Form -->
  <form method="POST" class="mb-4">
    <div class="mb-3">
      <label class="form-label">Enter ID to Edit</label>
      <input type="number" name="id" class="form-control" required>
    </div>
    <button class="btn btn-secondary">Load Asset</button>
  </form>

  <!-- Edit Form -->
  <?php if ($asset): ?>
    <form method="POST">
      <?php
      foreach ($asset as $key => $value) {
        if ($key === 'id') {
          echo "<input type='hidden' name='id' value='$value'>";
          continue;
        }
        echo "<div class='mb-3'>
                <label class='form-label'>" . ucwords(str_replace("_", " ", $key)) . "</label>
                <input type='text' name='$key' class='form-control' value='" . htmlspecialchars($value) . "' required>
              </div>";
      }
      ?>
      <button type="submit" name="update" class="btn btn-primary w-100">Update Asset</button>
    </form>
  <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
