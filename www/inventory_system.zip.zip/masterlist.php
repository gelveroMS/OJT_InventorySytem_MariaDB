<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit;
}
include 'config.php';

// Order by ID in ascending order
$result = $conn->query("SELECT * FROM assets ORDER BY id ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Master List</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: rgb(196, 196, 196); /* ash gray */
    }
    table {
      width: 100%;
      table-layout: fixed;
      word-wrap: break-word;
      font-size: 14px;
    }
    th, td {
      padding: 8px;
      vertical-align: top;
    }
    thead th {
      background-color: #343a40;
      color: white;
      text-align: center;
    }
    h2 {
      font-weight: bold;
    }
  </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="container mt-4">
  <h2 class="mb-4">Asset Master List</h2>

  <div class="table-responsive">
    <table class="table table-bordered align-middle">
      <thead>
        <tr>
          <th>ID</th>
          <th>Asset Tag</th>
          <th>Tag Number</th>
          <th>Brand Model</th>
          <th>Serial Number</th>
          <th>Processor</th>
          <th>HDD/SSD Size</th>
          <th>Recovery Tape</th>
          <th>Office Version</th>
          <th>Memory</th>
          <th>IP Address</th>
          <th>User</th>
          <th>Email Address</th>
          <th>Date Added</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
          <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
              <td><?= htmlspecialchars($row['id']) ?></td>
              <td><?= htmlspecialchars($row['asset_tag']) ?></td>
              <td><?= htmlspecialchars($row['tag_number']) ?></td>
              <td><?= htmlspecialchars($row['brand_model']) ?></td>
              <td><?= htmlspecialchars($row['serial_number']) ?></td>
              <td><?= htmlspecialchars($row['processor']) ?></td>
              <td><?= htmlspecialchars($row['hdd_ssd_size']) ?></td>
              <td><?= htmlspecialchars($row['recovery_tape']) ?></td>
              <td><?= htmlspecialchars($row['office_version']) ?></td>
              <td><?= htmlspecialchars($row['memory']) ?></td>
              <td><?= htmlspecialchars($row['ip_address']) ?></td>
              <td><?= htmlspecialchars($row['user']) ?></td>
              <td><?= htmlspecialchars($row['email_address']) ?></td>
              <td><?= htmlspecialchars($row['date_added']) ?></td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr>
            <td colspan="14" class="text-center text-muted">No records found.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
