<?php
if (!isset($_SESSION)) session_start();
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php">Inventory System</a>
    <div class="ms-auto d-flex align-items-center">
      <span class="text-white me-3">👤 <?= $_SESSION['user'] ?? 'Guest'; ?></span>
      <a class="btn btn-outline-light me-2" href="new_entry.php">New Entry</a>
      <a class="btn btn-outline-light me-2" href="edit_asset.php">Edit Asset</a>
      <a class="btn btn-outline-light me-2" href="masterlist.php">Master List</a>
      <a class="btn btn-danger btn-sm" href="logout.php">Logout</a>
    </div>
  </div>
</nav>
