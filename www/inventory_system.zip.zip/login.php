<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $username = $_POST['username'];
  $password = $_POST['password'];

  $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
  $stmt->bind_param("s", $username);
  $stmt->execute();
  $result = $stmt->get_result();

  if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    if (hash('sha256', $password) === $row['password']) {
      $_SESSION['user'] = $row['username'];
      header("Location: dashboard.php");
      exit;
    } else {
      $error = "❌ Invalid password.";
    }
  } else {
    $error = "❌ User not found.";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login - Inventory System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: url('asaka_image.jpg') no-repeat center center fixed;
      background-size: cover;
      background-color: rgb(196, 196, 196); /* fallback ash gray */
    }

    .login-container {
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .login-card {
      background-color: white;
      padding: 35px;
      border-radius: 12px;
      box-shadow: 0 0 25px rgba(0, 0, 0, 0.25);
      width: 100%;
      max-width: 400px;
    }

    .form-control {
      height: 45px;
    }

    .btn-primary {
      width: 100%;
    }

    label {
      font-weight: 500;
    }
  </style>
</head>
<body>
  <div class="login-container">
    <div class="login-card">
      <h3 class="text-center mb-4">🔐 Inventory Login</h3>

      <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
      <?php endif; ?>

      <form method="POST">
        <div class="mb-3">
          <label>Username</label>
          <input type="text" name="username" class="form-control" required>
        </div>
        <div class="mb-3">
          <label>Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Login</button>
      </form>
    </div>
  </div>
</body>
</html>
